import java.util.Scanner;
public class oddnumber {
    public static Scanner sc;

         public static void main(String[] args) {
        
            sc = new Scanner(System.in);
            int [] n = new int[5];
            System.out.println("Enter the number:");
            
            for(int i=0;i<5;i++){
                n[i] = sc.nextInt();
            
                if(n[i]%2!=0){
                    
                    System.out.print(n[i] + " ");
                    
                }
                
            }


         
        
    }


    
}
