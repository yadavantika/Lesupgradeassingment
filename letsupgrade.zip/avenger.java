import java.util.Scanner;

 
 public class avenger {
    public static Scanner sc;


    public String name, weapon, planet;
    public int age, power;

    public void getDetails(){

       
        sc = new Scanner(System.in);
        System.out.print(" \nEnter the Avenger name : ");
        name = sc.nextLine();
        System.out.print("\nEnter Weapon name :");
        weapon = sc.nextLine();
        System.out.print("\nEnter the planet name :");
        planet = sc.nextLine();
        System.out.print("\nEnter the age : ");
        age = sc.nextInt();
        System.out.print("\nEnter the Power :");
        power = sc.nextInt();
    }

    public void displayDetails(){
        System.out.println("\nTHe avenger name is " +name + " and the weapon is " +weapon+ "planet its " +planet+ "the age of avenger is " + age + " and power is " +power) ;

    }

     public static void main(String[] args) {
    
         avenger[] Avengers = new avenger[5];

         for (int i = 0; i<5;i++)
         {
             Avengers[i] = new avenger();
             Avengers[i].getDetails();
         }

         for (int i=0;i<5;i++){
             Avengers[i].displayDetails();
         }
        
    }




    
}
